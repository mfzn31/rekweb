<?php 

require 'functions.php';
$mahasiswas = query("SELECT * FROM mahasiswa");
// var_dump($mahasiswas);

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
</head>
<body>
	<a href="tambah.php"><button>Tambah Data</button></a>
	<br><br>
	<table border="1px" cellpadding="2px">
		<thead>
			<tr>
				<th>#</th>
				<th>Opsi</th>
				<th>Gambar</th>
				<th>Nama</th>
				<th>E-Mail</th>
				<th>Jurusan</th>
				<th>Universitas</th>
			</tr>
		</thead>
		<tbody>
			<?php $no = 1; ?>
			<?php foreach ($mahasiswas as $mhs): ?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td>
						<a href="">Hapus</a>
						<a href="">Ubah</a>
					</td>
					<td align="center">
						<img width="50px" align="center" src="../assets/img/<?= $mhs['gambar'] ?>">
					</td>
					<td>
						<?php echo $mhs['nama']; ?>
					</td>
					<td>
						<?php echo $mhs['email']; ?>
					</td>
					<td>
						<?php echo $mhs['jurusan']; ?>
					</td>
					<td>
						<?php echo $mhs['universitas']; ?>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</body>
</html>