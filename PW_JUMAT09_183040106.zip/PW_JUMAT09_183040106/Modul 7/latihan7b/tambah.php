<?php 

require 'functions.php';
if (isset($_POST['submit'])) {
	if (tambah($_POST) > 0) {
		echo "<script>
			alert('Data Berhasil Ditambahkan!');
			document.location.href = 'index.php';
		</script>";
	} else {
		echo "<script>
			alert('Data Gagal Ditambahkan!');
		</script>";
	}
	
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Tambah Data Mahasiswa</title>
 </head>
 <body>
 	<form action="" method="post">
 		<label for="nama">Nama</label>:
 		<input type="text" name="nama" id="nama" autofocus="on"><br>
 		<label for="email">E-Mail</label>:
 		<input type="text" name="email" id="email"><br>
 		<label for="email">Jurusan</label>:
 		<input type="text" name="jurusan" id="jurusan"><br>
 		<label for="email">Universitas</label>:
 		<input type="text" name="universitas" id="universitas"><br>
 		<label for="email">Gambar</label>:
 		<input type="text" name="gambar" id="gambar"><br>
 		<button type="submit" name="submit" id="submit">
 			Tambah Data
 		</button>
 	</form>
 </body>
 </html>