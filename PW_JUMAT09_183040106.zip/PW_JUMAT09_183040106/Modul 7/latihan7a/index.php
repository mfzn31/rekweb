<?php 

require 'functions.php';
$book = query("SELECT * FROM book");
// var_dump($mahasiswas);

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
</head>
<body>
	<table border="1px" cellpadding="2px">
		<thead>
			<tr>
				<th>No</th>
				<th>Opsi</th>
				<th>Gambar</th>
				<th>Nama</th>
				<th>E-Mail</th>
				<th>Jurusan</th>
				<th>Universitas</th>
			</tr>
		</thead>
		<tbody>
			<?php $no = 1; ?>
			<?php foreach ($book as $books): ?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td>
						<a href="">Hapus</a>
						<a href="">Ubah</a>
					</td>
					<td align="center">
						<img width="50px" align="center" src="./assets/img/<?= $books['foto'] ?>">
					</td>
					<td>
						<?php echo $books['nama_buku']; ?>
					</td>
					<td>
						<?php echo $books['nama_penulis']; ?>
					</td>
					<td>
						<?php echo $books['nama_penerbit']; ?>
					</td>
					<td>
						<?php echo $books['tahun_penerbit']; ?>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</body>
</html>