<?php

$conn = mysqli_connect("localhost", "root", "") or die("Koneksi Gagal!");
	mysqli_select_db($conn, "pw_183040106") or die("DB Salah!");
?>