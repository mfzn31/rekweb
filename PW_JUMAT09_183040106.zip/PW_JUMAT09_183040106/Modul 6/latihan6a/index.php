<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<div class="container">
		<?php
		$results = mysqli_query($conn, "SELECT * FROM book");
		while ($row = mysqli_fetch_assoc($result)){
		?>
		<div class="container">
			<div class="gambar">
				<img src="../img/<?= $row['gambar']?>">
			</div>
			<p class="nama"><?=['nama']?></p>
			<p class="nama"><?=['nama']?></p>
			<p class="nama"><?=['nama']?></p>
			<p class="nama"><?=['nama']?></p>
			<p class="nama"><?=['nama']?></p>
		</div>

		<?php }?>
	</div>
</body>
</html>