<!DOCTYPE html>
<html>
<head>
	<title>Index 183040106</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<style>
body {font: 32px/40px arial;
	  background: #E2E2E2;}

.container {width: 400px;
			margin: auto;
			background-color: #E2E2E2;
			padding: 20px;}

.content p {text-align: center;}

.content a {text-decoration: none;
			color: black;}
			
.content a:hover {background-color: lightblue;
				  padding: 3px;
				  color: brown;}
	</style>
<body>
	<?php
	echo "<div class='container'>";
		echo "<div class='content'>
			<p>Latihan Modul 5</p>
			<p><a href='Modul5/latihan5a.php'>latihan 5a</a></p>
			<p><a href='Modul5/latihan5b.php'>latihan 5b</a></p>
			<p><a href='Modul%5/latihan5c.php'>Latihan 5c</a></p>
			<p><a href='Modul%5/latihan5d.php'
			>Latihan 5d</a></p>
			<p><a href='Modul%5/latihan5d.php'>Latihan 5e</a></p>
			<p><a href='Modul%5/latihan5e/login.php'</p>
		</div>
		</div>"

	?>

</body>
</html>