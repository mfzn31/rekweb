<!DOCTYPE html>
<html>
<head>
	<title>Tugas 2</title>
</head>
	<style>
	</style>
<body>

	<?php
		$buku = [
			[
				"Foto"              => "<img src='./img/1.jpeg' width='250px'",
				"NamaBuku"         => "Anna Karenina",
				"NamaPenulis"      => "Leo Tolstoy",
				"NamaPenerbit"     => "The Russian Messenger",
				"TahunTerbit"      => "1877",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/2.jpeg' width='250px'",
				"NamaBuku"         => "To Kill a Mockingbird",
				"NamaPenulis"      => "Harper Lee",
				"NamaPenerbit"     => "J. B. Lippincott & Co.",
				"TahunTerbit"      => "1960",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/3.jpeg' width='250px'",
				"NamaBuku"         => "The Great Gatsby",
				"NamaPenulis"      => "F.Scott Fitzgerald",
				"NamaPenerbit"     => "Charles Scribner's Sons",
				"TahunTerbit"      => "1925",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/4.jpeg' width='250px'",
				"NamaBuku"         => "One Hundred Years of Solitude",
				"NamaPenulis"      => "Gabriel García Márquez",
				"NamaPenerbit"     => "PT Bentang Pustaka",
				"TahunTerbit"      => "1967",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/5.jpeg' width='250px'",
				"NamaBuku"         => "Don Quixote",
				"NamaPenulis"      => "Miguel de Cervantes",
				"NamaPenerbit"     => "Immortal ",
				"TahunTerbit"      => "1605",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/6.jpg' width='250px'",
				"NamaBuku"         => "Bumi Manusia",
				"NamaPenulis"      => "Pramoedya Ananta Noer",
				"NamaPenerbit"     => "Hasta Mitra",
				"TahunTerbit"      => "1980",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/7.jpg' width='250px'",
				"NamaBuku"         => "Laskar Pelangi",
				"NamaPenulis"      => "Andrea Hirata",
				"NamaPenerbit"     => "Bentang Pustaka",
				"TahunTerbit"      => "2005",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/8.jpg' width='250px'",
				"NamaBuku"         => "Anak Semua Bangsa",
				"NamaPenulis"      => "Pramoedya Ananta Noer",
				"NamaPenerbit"     => "Hasta Mitra",
				"TahunTerbit"      => "1981",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/9.jpg' width='250px'",
				"NamaBuku"         => "Ronggeng Dukuh Paruk",
				"NamaPenulis"      => "Ahmad Tohari",
				"NamaPenerbit"     => "‎Gramedia Pustaka Utama	",
				"TahunTerbit"      => "1982",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/10.jpg' width='250px'",
				"NamaBuku"         => "Saman",
				"NamaPenulis"      => "Ayu Utami",
				"NamaPenerbit"     => "Kepustakaan Populer Gramedia",
				"TahunTerbit"      => "1998",
				"JenisBuku"        => "Novel",
			],
			
		];
		?>
		<div class="container" align="center">
		<h1>Buku Terfavorit Sepanjang Masa</h1>
		<h4>Nama Nama Buku</h4>
		
		<?php foreach ($buku as $book) : ?>
			<li>
				<a href="latihan5c.php?Foto=<?= $book["Foto"]; ?>&NamaBuku=<?= $book["NamaBuku"]; ?>&NamaPenulis=<?= $book["NamaPenulis"]; ?>&NamaPenerbit=<?= $book["NamaPenerbit"]; ?>&TahunTerbit=<?= $book["TahunTerbit"]; ?>&JenisBuku=<?= $book["JenisBuku"]; ?>"><?= $book["NamaBuku"]; ?></a>
			</li>
		<?php endforeach;?>
		</div>
</body>
</html>