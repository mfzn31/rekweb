<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$buku = [
			[
				"Foto"              => "<img src='./img/1.jpeg' width='250px'",
				"NamaBuku"         => "Anna Karenina",
				"NamaPenulis"      => "Leo Tolstoy",
				"NamaPenerbit"     => "The Russian Messenger",
				"TahunTerbit"      => "1877",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/2.jpeg' width='250px'",
				"NamaBuku"         => "To Kill a Mockingbird",
				"NamaPenulis"      => "Harper Lee",
				"NamaPenerbit"     => "J. B. Lippincott & Co.",
				"TahunTerbit"      => "1960",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/3.jpeg' width='250px'",
				"NamaBuku"         => "The Great Gatsby",
				"NamaPenulis"      => "F.Scott Fitzgerald",
				"NamaPenerbit"     => "Charles Scribner's Sons",
				"TahunTerbit"      => "1925",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/4.jpeg' width='250px'",
				"NamaBuku"         => "One Hundred Years of Solitude",
				"NamaPenulis"      => "Gabriel García Márquez",
				"NamaPenerbit"     => "PT Bentang Pustaka",
				"TahunTerbit"      => "1967",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/5.jpeg' width='250px'",
				"NamaBuku"         => "Don Quixote",
				"NamaPenulis"      => "Miguel de Cervantes",
				"NamaPenerbit"     => "Immortal ",
				"TahunTerbit"      => "1605",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/6.jpg' width='250px'",
				"NamaBuku"         => "Bumi Manusia",
				"NamaPenulis"      => "Pramoedya Ananta Noer",
				"NamaPenerbit"     => "Hasta Mitra",
				"TahunTerbit"      => "1980",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/7.jpg' width='250px'",
				"NamaBuku"         => "Laskar Pelangi",
				"NamaPenulis"      => "Andrea Hirata",
				"NamaPenerbit"     => "Bentang Pustaka",
				"TahunTerbit"      => "2005",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/8.jpg' width='250px'",
				"NamaBuku"         => "Anak Semua Bangsa",
				"NamaPenulis"      => "Pramoedya Ananta Noer",
				"NamaPenerbit"     => "Hasta Mitra",
				"TahunTerbit"      => "1981",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/9.jpg' width='250px'",
				"NamaBuku"         => "Ronggeng Dukuh Paruk",
				"NamaPenulis"      => "Ahmad Tohari",
				"NamaPenerbit"     => "‎Gramedia Pustaka Utama	",
				"TahunTerbit"      => "1982",
				"JenisBuku"        => "Novel",
			],
			[
				"Foto"              => "<img src='./img/10.jpg' width='250px'",
				"NamaBuku"         => "Saman",
				"NamaPenulis"      => "Ayu Utami",
				"NamaPenerbit"     => "Kepustakaan Populer Gramedia",
				"TahunTerbit"      => "1998",
				"JenisBuku"        => "Novel",
			],
			
		];
		?>

	<table border="1" cellspacing="0" cellpadding="5" align="center">
			<tr class="hdr">
				<th>Foto</th>
				<th>Nama Buku</th>
				<th>Nama Penulis</th>
				<th>Nama Penerbit</th>
				<th>Tahun Terbit</th>
				<th>Jenis Buku</th>
			</tr>

				<tr>
					<td align="center"><?php echo $_GET["Foto"];?></td>
					<td align="center"><?php echo $_GET["NamaBuku"];?></td>
					<td align="center"><?php echo $_GET["NamaPenulis"];?></td>
					<td align="center"><?php echo $_GET["NamaPenerbit"];?></td>
					<td align="center"><?php echo $_GET["TahunTerbit"];?></td>
					<td align="center"><?php echo $_GET["JenisBuku"];?></td>
				</tr>
		</table>

</body>
</html>