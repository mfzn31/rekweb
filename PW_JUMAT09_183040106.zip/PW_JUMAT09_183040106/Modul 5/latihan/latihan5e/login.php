<?php

if ( isset ($_POST["submit"]) ) {
	if( $_POST["username"] == "admin" && $_POST["password"] == "123" ) {
		header("Location: admin.php");
		exit;
	}else {
		$error = true; 
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Admin</title>
</head>
<body>

	<?php if( isset($error) ) : ?>
		<p style="color: red; font-style: italic;">username / password salah!</p>
	<?php endif; ?>

	<div class="container" align="center">
		<h1>Login Admin</h1>
		<form action="" method="post">
			<li>
				<label for="username">username :</label>
				<input type="text" name="username" id="username">
			</li>
			<li>
				<label for="password">password :</label>
				<input type="password" name="password" id="password">
			</li>
			<li>
				<button type="submit" name="submit">Login</button>
			</li>
		</form>
	</div>

</body>
</html>