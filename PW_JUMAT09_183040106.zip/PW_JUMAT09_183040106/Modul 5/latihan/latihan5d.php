<?php $x = "";
	if(isset($_POST['angka-anda'])){
		$x = $_POST['angka-anda'];
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Modul 5 - Latihan 5d</title>
</head>
	<style>
		.kotak {
			width: 30px;
			height: 30px;
			text-align: center;
			line-height: 30px;
			border: 1px black solid;
			display: inline-block;
			margin: 2px;
			color: black;
		}
		.kotak1 {
			background-color: brown;
			width: 30px ;
			height: 30px ;
			text-align: center;
			line-height: 30px;
			border :1px black solid;
			display: inline-block;
			margin: 2px;
			color: black;
		}
		.clear {
			clear: both;
		}
	</style>
<body>
	<form action="" method="post">
		<label for="name">Masukan angka </label>
		<input type="text" name="angka-anda" id="angka-anda">
		<br>
		<button type="submit" name="submit">Kirim</button>
	</form>
	<?php
		for ($a=$x; $a>=1; $a--){
			for ($b=$a; $b>=1; $b--){
				if ($a % 2 == 1){
				echo "<div class='kotak clear'>$a</div>";
			}

				else {
				echo "<div class='kotak1 clear'>$a</div>";
				}
			}
				echo "<br>";
		}
	?>
</body>
</html>